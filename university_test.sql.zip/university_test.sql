-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Jul 19, 2017 at 01:46 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university_test`
--
CREATE DATABASE IF NOT EXISTS `university_test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `university_test`;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `course_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `courses_students`
--

CREATE TABLE `courses_students` (
  `id` bigint(20) unsigned NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses_students`
--

INSERT INTO `courses_students` (`id`, `course_id`, `student_id`) VALUES
(1, 17, 11),
(2, 26, 22),
(3, 35, 33),
(4, 44, 44),
(5, 53, 53),
(6, 53, 54),
(7, 54, 55),
(8, 63, 64),
(9, 63, 65),
(10, 64, 66),
(11, 75, 76),
(12, 75, 77),
(13, 76, 78),
(14, 87, 88),
(15, 87, 89),
(16, 88, 90),
(17, 99, 100),
(18, 99, 101),
(19, 100, 102),
(20, 111, 112),
(21, 111, 113),
(22, 112, 114),
(23, 124, 125),
(24, 124, 126),
(25, 125, 127),
(26, 137, 138),
(27, 137, 139),
(28, 138, 140),
(29, 150, 151),
(30, 150, 152),
(31, 151, 153),
(32, 163, 164),
(33, 163, 165),
(34, 164, 166),
(35, 175, 165),
(36, 175, 166),
(37, 176, 167),
(38, 176, 177),
(39, 176, 178),
(40, 177, 179),
(41, 188, 178),
(42, 188, 179),
(43, 189, 180),
(44, 189, 190),
(45, 189, 191),
(46, 190, 192),
(47, 201, 191),
(48, 201, 192),
(49, 202, 193),
(50, 202, 203),
(51, 202, 204),
(52, 203, 205),
(53, 214, 204),
(54, 214, 205),
(55, 215, 206),
(56, 215, 216),
(57, 215, 217),
(58, 216, 218),
(59, 227, 217),
(60, 227, 218),
(61, 228, 219),
(62, 228, 229),
(63, 228, 230),
(64, 229, 231),
(65, 230, 240),
(66, 231, 240),
(67, 232, 241),
(68, 241, 242),
(69, 241, 243),
(70, 242, 244),
(71, 243, 253),
(72, 244, 253),
(73, 245, 254),
(74, 246, 255),
(75, 255, 256),
(76, 255, 257),
(77, 256, 258),
(78, 257, 267),
(79, 258, 267),
(80, 259, 268),
(81, 260, 269),
(82, 269, 270),
(83, 269, 271),
(84, 270, 272),
(85, 271, 281),
(86, 272, 281),
(87, 273, 282),
(89, 283, 284),
(90, 283, 285),
(91, 284, 286),
(92, 285, 295),
(93, 286, 295),
(94, 287, 296),
(96, 297, 298),
(97, 297, 299),
(98, 298, 300),
(99, 309, 301),
(100, 309, 302),
(101, 310, 303),
(102, 313, 312),
(103, 314, 312),
(104, 315, 313);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `name` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `courses_students`
--
ALTER TABLE `courses_students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `courses_students`
--
ALTER TABLE `courses_students`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=105;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
